package com.user.wallet.services;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.user.wallet.model.PassbookResponseModel;
import com.user.wallet.model.UserAmountDetail;
import com.user.wallet.model.UserPassbook;
import com.user.wallet.repository.UserAmountRepository;
import com.user.wallet.repository.UserPassbookRepository;

/**
 * This class is for all operation related to the transactions
 *
 */
@Component("userWalletManagementService")
public class UserWalletService {

	private static final Logger logger = LogManager.getLogger(UserWalletService.class);
	@Autowired
	UserPassbookRepository userPassbookRepository;
	@Autowired
	UserAmountRepository userAmountRepository;

	/**
	 * this method for add money to the wallet
	 * 
	 * @param userPassbook
	 * @return
	 */
	public List<UserPassbook> addMoneyToWallet(UserPassbook userPassbook) {
		logger.info("In addMoneyToWallet method of service!! " + userPassbook.getUserID());
		List<UserPassbook> userPassbookUpdated = userPassbookRepository.findByUserID(userPassbook.getUserID());
		try {
			userPassbook.setTransactionDate(new Date());
			userPassbookRepository.save(userPassbook);
			UserAmountDetail existUserAmountDetail = userAmountRepository.findByUserId(userPassbook.getUserID());
			existUserAmountDetail.setAmmount(existUserAmountDetail.getAmmount() + userPassbook.getAmmount());
			userAmountRepository.save(existUserAmountDetail);
			userPassbookUpdated = userPassbookRepository.findByUserID(userPassbook.getUserID());
		} catch (Exception e) {
			logger.error("Getting exception in adding money to wallet :: " + userPassbook.getUserID()
					+ " exception is :: " + e.getStackTrace());
		}
		logger.info("In addMoneyToWallet method of service!! " + userPassbook.getUserID());
		return userPassbookUpdated;
	}

	/**
	 * this method for pay money from wallet
	 * 
	 * @param userPassbook
	 * @return
	 */
	public List<UserPassbook> payMoneyFromWallet(UserPassbook userPassbook) {
		logger.info("In payMoneyFromWallet method of service!! " + userPassbook.getUserID());
		List<UserPassbook> userPassbookUpdated = userPassbookRepository.findByUserID(userPassbook.getUserID());
		try {
			userPassbook.setTransactionDate(new Date());
			userPassbookRepository.save(userPassbook);
			UserAmountDetail existUserAmountDetail = userAmountRepository.findByUserId(userPassbook.getUserID());
			existUserAmountDetail.setAmmount(existUserAmountDetail.getAmmount() - userPassbook.getAmmount());
			userAmountRepository.save(existUserAmountDetail);
			userPassbookUpdated = userPassbookRepository.findByUserID(userPassbook.getUserID());
		} catch (Exception e) {
			logger.error("Getting exception in paying money from wallet :: " + userPassbook.getUserID()
					+ " exception is :: " + e.getStackTrace());
		}
		logger.info("In payMoneyFromWallet method of service!! " + userPassbook.getUserID());
		return userPassbookUpdated;
	}

	/**
	 * this method to view the user passbook
	 * 
	 * @param userId
	 * @return
	 */
	public PassbookResponseModel viewUserWalletPassbook(String userId) {
		logger.info("In viewUserWalletPassbook method of service!! " + userId);
		PassbookResponseModel passbookResponseModel = new PassbookResponseModel();
		try {
			List<UserPassbook> userPassbook = userPassbookRepository.findByUserID(userId);
			passbookResponseModel.setUserPassbook(userPassbook);
			UserAmountDetail userAmountDetail = userAmountRepository.findByUserId(userId);
			passbookResponseModel.setUserAmountDetail(userAmountDetail);
		} catch (Exception e) {
			logger.error("Getting exception in viewing wallet Passbook:: " + userId + " exception is :: "
					+ e.getStackTrace());
		}
		logger.info("Out viewUserWalletPassbook method of service!! " + userId);
		return passbookResponseModel;
	}

}
