package com.user.wallet.exception;

public class UserIsNotExistException extends RuntimeException{
	private static final long serialVersionUID = -6486707134924288421L;
	/**
	 * @param userId
	 */
	public UserIsNotExistException(String userId) {
        super("User ID "+userId+" is not Exist!!");
    }
}
