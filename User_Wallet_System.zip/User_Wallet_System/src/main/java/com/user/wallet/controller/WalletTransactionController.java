package com.user.wallet.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.wallet.model.PassbookResponseModel;
import com.user.wallet.model.UserPassbook;
import com.user.wallet.services.UserWalletService;

/**
 * This is a controller class which is written for all operations which are related to transactions
 *
 */
@RestController
@RequestMapping("/userWallet")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class WalletTransactionController {
	
	/** The Logger. */
	private static final Logger logger = LogManager.getLogger(WalletTransactionController.class);
	
	@Autowired UserWalletService userWalletService;
	
	/**
	 * this method is for add money into the wallet
	 * @param userPassbook
	 */
	@PostMapping("/addMoney")
    public List<UserPassbook> addMoney(@RequestBody UserPassbook userPassbook){
		
		logger.info("in addMoney method of controller:" + userPassbook.toString());		
		List<UserPassbook> userPassbookUpdated=null;
		userPassbookUpdated=userWalletService.addMoneyToWallet(userPassbook);
		logger.info("out addMoney method of controller:" + userPassbook.toString());
		return userPassbookUpdated;
    }
	
	/**
	 * this is the method for pay money from wallet
	 * @param userPassbook
	 */
	@PostMapping("/payMoney")
    public List<UserPassbook> payMoney(@RequestBody UserPassbook userPassbook){
		
		logger.info("in payMoney method of controller:" + userPassbook.toString());	
		List<UserPassbook> userPassbookUpdated=null;
		userPassbookUpdated=userWalletService.payMoneyFromWallet(userPassbook);
		logger.info("out payMoney method of controller:" + userPassbook.toString());
		return userPassbookUpdated;
    }
	
	/**
	 * this is the method for view passbook
	 * @param userId
	 * @return
	 */
	@GetMapping("/getPassbook")
    public PassbookResponseModel getPassbook(@RequestParam String userId){
		
		logger.info("in getPassbook method of controller:" + userId);	
		PassbookResponseModel transactionList=null;
		transactionList=userWalletService.viewUserWalletPassbook(userId) ;
		logger.info("out getPassbook method of controller:" + userId);	
		return transactionList;
    }

}
