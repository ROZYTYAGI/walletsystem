package com.user.wallet.model;

import java.util.List;

public class PassbookResponseModel {
	
	private UserAmountDetail userAmountDetail;
	private List<UserPassbook> userPassbook;
	public UserAmountDetail getUserAmountDetail() {
		return userAmountDetail;
	}
	public void setUserAmountDetail(UserAmountDetail userAmountDetail) {
		this.userAmountDetail = userAmountDetail;
	}
	public List<UserPassbook>  getUserPassbook() {
		return userPassbook;
	}
	public void setUserPassbook(List<UserPassbook>  userPassbook) {
		this.userPassbook = userPassbook;
	}
	

}
