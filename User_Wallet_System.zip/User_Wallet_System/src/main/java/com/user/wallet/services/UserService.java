package com.user.wallet.services;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.user.wallet.exception.UserAlreadyExistException;
import com.user.wallet.exception.UserIsNotExistException;
import com.user.wallet.exception.WrongPasswordException;
import com.user.wallet.model.UserAmountDetail;
import com.user.wallet.model.UserProfileDetails;
import com.user.wallet.repository.UserAmountRepository;
import com.user.wallet.repository.UserRepository;
import com.user.wallet.util.PaswordEncrytpionDecrytpion;

/**
 * this is a service class which is used for all implementation related to User Profile
 *
 */
@Component("userManagementService")
public class UserService {

	private static final Logger logger = LogManager.getLogger(UserService.class);

	@Autowired
	UserRepository userRepository;
	@Autowired
	UserAmountRepository userAmountRepository;
	@Autowired
	PaswordEncrytpionDecrytpion paswordEncrytpionDecrytpion;

	/**
	 * this method is used for creation new account
	 * @param userProfileDetails
	 * @return
	 */
	public UserProfileDetails createUser(UserProfileDetails userProfileDetails) {
		logger.info("in createUser method of user service :: "+userProfileDetails.getUserID());
		UserProfileDetails persistentUser = null;

		if (userProfileDetails != null) {
			userProfileDetails.setId(Long.toString((new Date()).getTime()));
			userProfileDetails.setCreatedDate(new Date());
			userProfileDetails
					.setPassword(paswordEncrytpionDecrytpion.passEncryption(userProfileDetails.getPassword()));
			UserProfileDetails userProfile = userRepository.findByUserID(userProfileDetails.getUserID());
			if (userProfile == null) {
				logger.info("No User found, going to persist the user data");
				persistentUser = userRepository.save(userProfileDetails);
				createPassbook(persistentUser);
			}

			else {
				logger.info("User found, throwing UserAlreadyExistException!!");
				throw new UserAlreadyExistException(userProfileDetails.getUserID());
			}

			

		}
		logger.info("in createUser method of user service :: "+userProfileDetails.getUserID());
		return persistentUser;

	}

	/**
	 * this method will create initially wallet with amount 0
	 * @param persistentUser
	 */
	private boolean createPassbook(UserProfileDetails persistentUser) {
		logger.info("In createPassbook method of service!! "+persistentUser.getUserID());
		try{
		UserAmountDetail userAmountDetail = new UserAmountDetail();
		userAmountDetail.setId(Long.toString((new Date()).getTime()));
		userAmountDetail.setUserId(persistentUser.getUserID());
		userAmountDetail.setAmmount(0);
		userAmountRepository.save(userAmountDetail);
		logger.info("Intialized 0 ammount in User Wallet Passbook!!");
		return true;
		}catch (Exception e) {
			logger.error("Getting issue for initialising the passbook!!"+e.getStackTrace());
			return false;
		}
		

	}

	/**
	 * this method is to view the user profile on the behalf of userId
	 * @param userID
	 * @return UserProfileDetails
	 */
	public UserProfileDetails getProfile(String userID) {
		logger.info("In getProfile method of service!! "+userID);
		UserProfileDetails userProfile = userRepository.findByUserID(userID);
		if (userProfile == null) {
			logger.info("No User found!!");
			throw new UserIsNotExistException(userID);
		}
		else {
			logger.info("Out getProfile method of service!! "+userID);
			return userProfile;
		}

	}

	/**
	 * This method is used for user signing in
	 * @param userID
	 * @param pass
	 * @return UserProfileDetails
	 */
	public UserProfileDetails getSignIn(String userID, String pass) {
		logger.info("In getSignIn method of service!! "+userID);
		UserProfileDetails userProfileDetails = userRepository.findByUserID(userID);
		if (userProfileDetails == null) {
			logger.info("No User found!!");
			throw new UserIsNotExistException(userID);

		} else {
			if (pass.equals(paswordEncrytpionDecrytpion.passDecryption(userProfileDetails.getPassword()))) {
				logger.info("Out getSignIn method of service!! "+userID);
				return userProfileDetails;
			} else {
				throw new WrongPasswordException(userID);
			}

		}

	}

	/**
	 * this method is used for updating any field in user profile
	 * @param userProfileUpdateDetails
	 * @return
	 */
	public UserProfileDetails updateProfile(UserProfileDetails userProfileUpdateDetails) {
		logger.info("In updateProfile method of service!! "+userProfileUpdateDetails.getUserID());
		UserProfileDetails userProfile = userRepository.findByUserID(userProfileUpdateDetails.getUserID());
		if (userProfile == null) {
			logger.info("No User found!!");
			throw new UserIsNotExistException(userProfileUpdateDetails.getUserID());
		} else {
			if (!userProfileUpdateDetails.getPassword().isEmpty()) {
				userProfile.setPassword(
						paswordEncrytpionDecrytpion.passEncryption(userProfileUpdateDetails.getPassword()));
			}
			userRepository.save(userProfile);
			logger.info("Out updateProfile method of service!! "+userProfileUpdateDetails.getUserID());
			return userProfile;
		}
	}

}
