package com.user.wallet.exception;

public class UserAlreadyExistException extends RuntimeException{
	private static final long serialVersionUID = -6486707134924288421L;

	/**
	 * @param userId
	 */
	public UserAlreadyExistException(String userId) {
        super("User ID "+userId+" is already Exist!!");
    }


}
