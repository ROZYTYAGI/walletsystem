package com.user.wallet.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import com.user.wallet.model.UserAmountDetail;

public interface UserAmountRepository extends MongoRepository<UserAmountDetail, Integer>, QuerydslPredicateExecutor<UserAmountDetail> {

	UserAmountDetail findByUserId(String userID);
}
