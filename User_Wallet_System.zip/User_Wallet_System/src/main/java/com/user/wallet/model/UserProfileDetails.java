package com.user.wallet.model;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document(collection = "User_Profile")
public class UserProfileDetails implements Serializable{
	
	private static final long serialVersionUID = 7874467815492648676L;

	/** The id. */
	@Id
	private String id;
	

	@Override
	public String toString() {
		return "UserProfileDetails [id=" + id + ", createdDate=" + createdDate + ", displayName=" + displayName
				+ ", emailID=" + emailID + ", userID=" + userID + ", password=" + password + "]";
	}

	private Date createdDate;
	
	private String displayName;
	
	@NotNull(message = "emailID must not be null")
	private String emailID;
	
	@NotNull(message = "userID must not be null")
	private String userID;
	
	@NotNull(message = "password must not be null")
	private String password;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
