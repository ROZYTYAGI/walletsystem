package com.user.wallet.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import com.user.wallet.model.UserProfileDetails;

public interface UserRepository extends MongoRepository<UserProfileDetails, Integer>, QuerydslPredicateExecutor<UserProfileDetails>{

	UserProfileDetails findByUserID(String userID);
}
