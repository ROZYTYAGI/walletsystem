package com.user.wallet.exception;

public class WrongPasswordException extends RuntimeException {
	private static final long serialVersionUID = -6486707134924288421L;
	/**
	 * @param userId
	 */
	public WrongPasswordException(String userId) {
        super(" Password is not correct for User ID "+userId+"!!");
    }

}
