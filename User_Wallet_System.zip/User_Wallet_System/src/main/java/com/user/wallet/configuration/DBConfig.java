package com.user.wallet.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.mapping.event.ValidatingMongoEventListener;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;

@Configuration
@EnableMongoRepositories(basePackages = "com.user.wallet.repository", mongoTemplateRef = "mongoTemplate")
public class DBConfig {
	  
	/**
	 * @param mongoFactory
	 * @return
	 * @throws MongoException
	 * @throws BeanCreationException
	 */
	@Bean(name = "mongoTemplate")
	public MongoTemplate mongoTemplate(@Qualifier("mongoFactory") MongoDbFactory mongoFactory) throws MongoException, BeanCreationException {
		return new MongoTemplate(mongoFactory);
	}

	/**
	 * @param properties
	 * @return
	 * @throws MongoException
	 */
	@Bean("mongoFactory")
	public MongoDbFactory mongoFactory(@Qualifier("mongoProperties") MongoSettingsProperties properties)
			throws MongoException {
		MongoClientOptions.Builder builder = new MongoClientOptions.Builder();
		builder.connectionsPerHost(properties.getMaxConnectionsPerHost());
		builder.minConnectionsPerHost(properties.getMinConnectionsPerHost());

		builder.maxWaitTime(properties.getMaxWaitTime());
		builder.maxConnectionIdleTime(properties.getMaxConnectionIdleTime());
		builder.maxConnectionLifeTime(properties.getMaxConnectionLifeTime());
		builder.connectTimeout(properties.getConnectTimeout());
		MongoClientOptions mongoClientOptions = builder.build();

		// MongoDB address list
		List<ServerAddress> serverAddresses = new ArrayList<ServerAddress>();
		for (String address : properties.getAddress()) {
			String[] hostAndPort = address.split(":");
			String host = hostAndPort[0];
			Integer port = Integer.parseInt(hostAndPort[1]);
			ServerAddress serverAddress = new ServerAddress(host, port);
			serverAddresses.add(serverAddress);
		}

		return new SimpleMongoDbFactory(new MongoClient(serverAddresses, mongoClientOptions), properties.getDatabase());
	}
	@Bean
    public ValidatingMongoEventListener validatingMongoEventListener() {
        return new ValidatingMongoEventListener(validator());
    }

    @Bean
    public LocalValidatorFactoryBean validator() {
        return new LocalValidatorFactoryBean();
    }
	
	 /**
	 * @return
	 * @throws BeanCreationException
	 */
	@Bean(name = "mongoProperties")
	 public MongoSettingsProperties properties() throws BeanCreationException {
		 return new	 MongoSettingsProperties(); 
		 }
	 
}
