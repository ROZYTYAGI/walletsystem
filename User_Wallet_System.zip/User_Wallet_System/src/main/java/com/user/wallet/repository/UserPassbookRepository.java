package com.user.wallet.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import com.user.wallet.model.UserPassbook;

public interface UserPassbookRepository extends MongoRepository<UserPassbook, Integer>, QuerydslPredicateExecutor<UserPassbook>{

	List<UserPassbook> findByUserID(String userID);
}
