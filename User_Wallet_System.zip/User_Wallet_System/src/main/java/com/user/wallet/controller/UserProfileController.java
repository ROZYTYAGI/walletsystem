package com.user.wallet.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.wallet.model.UserProfileDetails;
import com.user.wallet.services.UserService;


/**
 * this is a controller class which is using for user profile operations
 *
 */
@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserProfileController {

	/** The Logger. */
	private static final Logger logger = LogManager.getLogger(UserProfileController.class);
	
	@Autowired UserService userService;
	
	/**
	 * this method is for signup
	 * @param userProfileDetails
	 */
	@PostMapping("/signUp")
    public void signUp(@RequestBody UserProfileDetails userProfileDetails){
		
		logger.info("enter In User sign up method :" + userProfileDetails.toString());
		
		if (userService.createUser(userProfileDetails) == null ) {
			
			logger.info("User signup has not done!!");
        }
		logger.info("User has signed up!!");
    }
	
	/**
	 * this method is for sign in
	 * @param userID
	 * @param pass
	 */
	@GetMapping("/signIn")
    public void signIn(@RequestParam String userID,@RequestParam String pass){
		logger.info("in sign in controller method :" + userID);
		
       if (userService.getSignIn(userID,pass) == null ) {
			
			logger.info("User signIn has failed!!");
        }
		logger.info("User has signed In!!");
		
    }
	
	/**
	 * this method is for view user profile
	 * @param userID
	 * @return
	 */
	@GetMapping("/viewProfile")
    public UserProfileDetails viewProfile(@RequestParam String userID){
		logger.info("in viewProfile controller method :" + userID);
		UserProfileDetails userProfileDetails=null;
		userProfileDetails=userService.getProfile(userID);		
		logger.info("out viewProfile controller method :" + userID);
		return userProfileDetails;
    }
	
	/**
	 * this method is for update user profile
	 * @param userProfileUpdateDetails
	 * @return
	 */
	@PatchMapping("/updateProfile")
    public UserProfileDetails updateProfile(@RequestBody UserProfileDetails userProfileUpdateDetails){
		logger.info("in userProfileUpdateDetails controller method :" + userProfileUpdateDetails.toString());
		UserProfileDetails userProfileDetails=null;
		userProfileDetails=userService.updateProfile(userProfileUpdateDetails);		
		logger.info("out userProfileUpdateDetails controller method :" + userProfileUpdateDetails.toString());
		return userProfileDetails;
    }
	

}
