package com.user.wallet.configuration;

import java.util.Collections;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties(prefix = "spring.data.mongodb")
public class MongoSettingsProperties {
	
	/**
	 * 
	 */
	public MongoSettingsProperties() {
		super();
	}
	
	/** The address. */
	private List<String> address;
	
	/** The database. */
	private String database;
	
	/** The minConnectionsPerHost. */
	private Integer minConnectionsPerHost;
	
	/** The maxConnectionsPerHost. */
	private Integer maxConnectionsPerHost;
	
	/** The maxWaitTime. */
	private Integer maxWaitTime;
	
	/** The maxConnectionIdleTime. */
	private Integer maxConnectionIdleTime;
	
	/** The maxConnectionLifeTime. */
	private Integer maxConnectionLifeTime;
	
	/** The connectTimeout. */
	private Integer connectTimeout;

	/**
	 * @return the address
	 */
	public List<String> getAddress() {
		return Collections.unmodifiableList(address);
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(List<String> address) {
		this.address = Collections.unmodifiableList(address);
	}
	/**
	 * @return the database
	 */
	public String getDatabase() {
		return database;
	}
	/**
	 * @param database the database to set
	 */
	public void setDatabase(String database) {
		this.database = database;
	}
	/**
	 * @return the minConnectionsPerHost
	 */
	public Integer getMinConnectionsPerHost() {
		return minConnectionsPerHost;
	}
	/**
	 * @param minConnectionsPerHost the minConnectionsPerHost to set
	 */
	public void setMinConnectionsPerHost(Integer minConnectionsPerHost) {
		this.minConnectionsPerHost = minConnectionsPerHost;
	}
	/**
	 * @return the maxConnectionsPerHost
	 */
	public Integer getMaxConnectionsPerHost() {
		return maxConnectionsPerHost;
	}
	/**
	 * @param maxConnectionsPerHost the maxConnectionsPerHost to set
	 */
	public void setMaxConnectionsPerHost(Integer maxConnectionsPerHost) {
		this.maxConnectionsPerHost = maxConnectionsPerHost;
	}
	/**
	 * @return the maxWaitTime
	 */
	public Integer getMaxWaitTime() {
		return maxWaitTime;
	}
	/**
	 * @param maxWaitTime the maxWaitTime to set
	 */
	public void setMaxWaitTime(Integer maxWaitTime) {
		this.maxWaitTime = maxWaitTime;
	}
	/**
	 * @return the maxConnectionIdleTime
	 */
	public Integer getMaxConnectionIdleTime() {
		return maxConnectionIdleTime;
	}
	/**
	 * @param maxConnectionIdleTime the maxConnectionIdleTime to set
	 */
	public void setMaxConnectionIdleTime(Integer maxConnectionIdleTime) {
		this.maxConnectionIdleTime = maxConnectionIdleTime;
	}
	/**
	 * @return the maxConnectionLifeTime
	 */
	public Integer getMaxConnectionLifeTime() {
		return maxConnectionLifeTime;
	}
	/**
	 * @param maxConnectionLifeTime the maxConnectionLifeTime to set
	 */
	public void setMaxConnectionLifeTime(Integer maxConnectionLifeTime) {
		this.maxConnectionLifeTime = maxConnectionLifeTime;
	}
	/**
	 * @return the connectTimeout
	 */
	public Integer getConnectTimeout() {
		return connectTimeout;
	}
	/**
	 * @param connectTimeout the connectTimeout to set
	 */
	public void setConnectTimeout(Integer connectTimeout) {
		this.connectTimeout = connectTimeout;
	}
	

}
