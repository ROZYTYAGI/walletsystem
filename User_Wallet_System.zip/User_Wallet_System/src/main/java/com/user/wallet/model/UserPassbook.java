package com.user.wallet.model;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "User_Passbook")
public class UserPassbook implements Serializable {
	private static final long serialVersionUID = 78744678549268676L;

	/** The id. */
	@Id
	private String id;
	@Override
	public String toString() {
		return "UserPassbook [id=" + id + ", userID=" + userID + ", transactionType=" + transactionType + ", ammount="
				+ ammount + ", otherUserID=" + otherUserID + ", otherUserDisplayName=" + otherUserDisplayName
				+ ", transactionDate=" + transactionDate + "]";
	}
	@NotNull(message = "userID must not be null")
	private String userID;
	@NotNull(message = "transactionType must not be null")
	private String transactionType;
	@NotNull(message = "ammount must not be null")
	private double ammount;
	@NotNull(message = "otherUserID must not be null")
	private String otherUserID;
	private String otherUserDisplayName;
	private Date transactionDate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmmount() {
		return ammount;
	}
	public void setAmmount(double ammount) {
		this.ammount = ammount;
	}
	public String getOtherUserID() {
		return otherUserID;
	}
	public void setOtherUserID(String otherUserID) {
		this.otherUserID = otherUserID;
	}
	public String getOtherUserDisplayName() {
		return otherUserDisplayName;
	}
	public void setOtherUserDisplayName(String otherUserDisplayName) {
		this.otherUserDisplayName = otherUserDisplayName;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

}
