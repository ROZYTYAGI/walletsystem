package com.user.wallet.util;

import org.springframework.stereotype.Component;

/**
 * class for password encryption and decryption
 *
 */
@Component("passwordService")
public class PaswordEncrytpionDecrytpion {

	
	/**
	 * method for password encryption
	 * @param password
	 * @return
	 */
	public String passEncryption(String password) {
		//we can write our encryption algo here but for now i have just make this block.

		String encryptedPass = password;

		return encryptedPass;

	}

	/**
	 * method for password decryption
	 * @param password
	 * @return
	 */
	public String passDecryption(String password) {
		//we can write our decryption algo here but for now i have just make this block.
		String decryptedPass = password;

		return decryptedPass;

	}

}
