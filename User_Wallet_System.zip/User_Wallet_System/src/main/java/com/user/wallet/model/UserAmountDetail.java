package com.user.wallet.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "User_Amount")
public class UserAmountDetail implements Serializable {
	private static final long serialVersionUID = 7874467815492648676L;

	/** The id. */
	@Id
	private String id;

	@Override
	public String toString() {
		return "UserAmountDetail [id=" + id + ", userId=" + userId + ", ammount=" + ammount + "]";
	}
	@NotNull(message = "userId must not be null")
	private String userId;
	private double ammount;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public double getAmmount() {
		return ammount;
	}
	public void setAmmount(double ammount) {
		this.ammount = ammount;
	}
}
